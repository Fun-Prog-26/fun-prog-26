# checkReverse
