{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}

import qualified Data.ByteString.Lazy as BL
import Data.Csv 
import GHC.Generics (Generic)
import Data.Either (partitionEithers)
import Control.Monad (forM_)
import Data.Vector (toList)
import Data.Csv (FromNamedRecord(..), NamedRecord, decodeByName)

data Student = Student
    { studentId :: String
    , name      :: String
    , age       :: Int
    , avg       :: Double
    , credits   :: Int
    } deriving (Show, Generic)

parseCredits :: Int -> Parser Int
parseCredits c =
    if c `mod` 5 == 0 && c <= 240
        then pure c
        else fail $ "Invalid credits: " ++ show c

parseAge :: Int -> Parser Int
parseAge a =
    if a < 90
        then pure a
        else fail $ "Invalid age: " ++ show a

instance FromNamedRecord Student where
    parseNamedRecord r = do
        studentId' <- r .: "studentId"
        name'      <- r .: "Name"
        age'       <- r .: "age" >>= parseAge
        avg'       <- r .: "avg"
        credits'   <- r .: "credits" >>= parseCredits
        return $ Student studentId' name' age' avg' credits'

main :: IO ()
main = do
    csvData <- BL.readFile "students.csv"
    case decodeByName csvData of
        Left err -> putStrLn $ "CSV format error: " ++ err
        Right (_, vec) -> do
            let records = zip [2..] (toList vec)  -- Start from 2 to account for header row
            let results = map parseStudentRecord records
                (errs, students) = partitionEithers results

            -- Print successfully parsed students
            putStrLn "\nParsed Students:"
            forM_ students $ \p ->
                putStrLn $ studentId p ++ ", Name: " ++ name p ++ ", Age: " ++
                    show (age p) ++ ", Avg: " ++ show (avg p) ++ ", Credits: " ++ show (credits p)

            -- Print errors
            putStrLn "\nParsing Errors:"
            forM_ errs putStrLn

-- Parse a single record, providing clear error messages
parseStudentRecord :: (Int, NamedRecord) -> Either String Student
parseStudentRecord (lineNumber, rec) =
    case runParser (parseNamedRecord rec) of
        Left err -> Left $ "Error at CSV line " ++ show lineNumber ++ ": " ++ err
        Right student -> Right student